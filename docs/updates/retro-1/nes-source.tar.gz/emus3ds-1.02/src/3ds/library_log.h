#define LIBRARY_LOG_PATH "sdmc:/3ds/nes-library/last-run.log"
#include "library_diagnostic.h"
