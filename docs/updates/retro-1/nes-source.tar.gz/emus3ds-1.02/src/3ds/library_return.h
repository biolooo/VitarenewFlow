#ifndef LIBRARY_RETURN_H
#define LIBRARY_RETURN_H
#include <3ds.h>
#include <string.h>
static inline bool librarySetReturnTarget(void) {
    Handle port;
    if (R_FAILED(svcConnectToPort(&port,"hb:ldr"))) return false;
    const char *path="/3ds/3ds-library/3ds-library.3dsx";
    u32 args[0x100]={0}; args[0]=1;
    strcpy((char*)(args+1),"sdmc:/3ds/3ds-library/3ds-library.3dsx");
    u32 *ipc=getThreadCommandBuffer();
    ipc[0]=IPC_MakeHeader(3,0,2); ipc[1]=IPC_Desc_StaticBuffer(sizeof(args),1); ipc[2]=(u32)args;
    Result rc=svcSendSyncRequest(port); if(R_SUCCEEDED(rc))rc=(Result)ipc[1];
    if(R_SUCCEEDED(rc)) {
        ipc[0]=IPC_MakeHeader(2,0,2); ipc[1]=IPC_Desc_StaticBuffer(strlen(path)+1,0); ipc[2]=(u32)path;
        rc=svcSendSyncRequest(port); if(R_SUCCEEDED(rc))rc=(Result)ipc[1];
    }
    svcCloseHandle(port); return R_SUCCEEDED(rc);
}
static inline bool libraryReturnRequested(void) {
    const u32 combo=KEY_L|KEY_R|KEY_Y;
    if((hidKeysHeld()&combo)!=combo)return false;
    return librarySetReturnTarget();
}
#endif
