#include "copyright.h"


#ifndef _PPU_H_
#define _PPU_H_

#include "port.h"
#include "3dsgpu.h"
#include "3dsimpl_gpu.h"
#include "ppuvsect.h"
#include "cliphw.h"


#define FIRST_VISIBLE_LINE 1

extern uint8 GetBank;
extern uint16 SignExtend [2];

#define TILE_2BIT 0
#define TILE_4BIT 1
#define TILE_8BIT 2

#define MAX_2BIT_TILES 4096
#define MAX_4BIT_TILES 2048
#define MAX_8BIT_TILES 1024

#define PPU_H_BEAM_IRQ_SOURCE	(1 << 0)
#define PPU_V_BEAM_IRQ_SOURCE	(1 << 1)
#define GSU_IRQ_SOURCE		(1 << 2)
#define SA1_IRQ_SOURCE		(1 << 7)
#define SA1_DMA_IRQ_SOURCE	(1 << 5)

struct ClipData {
    uint32  Count [6];
    uint32  Left [6][6];
    uint32  Right [6][6];
};



struct InternalPPU {
    bool8  ColorsChanged;
    uint8  HDMA;
    bool8  HDMAStarted;
    bool8  InHDMA;
    bool8  HDMAAnyCGRAMTouched;
    uint8  MaxBrightness;
    bool8  LatchedBlanking;
    bool8  OBJChanged;
    bool8  RenderThisFrame;
    bool8  DirectColourMapsNeedRebuild;
    uint32 FrameCount;
    uint32 RenderedFramesCount;
    uint32 DisplayedRenderedFrameCount;
    uint32 SkippedFrames;
    uint32 FrameSkip;
    uint8  *TileCache [3];
    uint8  *TileCached [3];
#ifdef CORRECT_VRAM_READS
    uint16 VRAMReadBuffer;
#else
    bool8  FirstVRAMRead;
#endif
    bool8  DoubleHeightPixels;
    bool8  Interlace;
    bool8  InterlaceSprites;
    bool8  DoubleWidthPixels;
    int    RenderedScreenHeight;
    int    RenderedScreenWidth;
    uint32 Red [256];
    uint32 Green [256];
    uint32 Blue [256];
    uint8  *XB;
    uint16 ScreenColors [256];
    int	   PreviousLine;
    int	   CurrentLine;
    int	   Controller;
    uint32 Joypads[5];
    uint32 SuperScope;
    uint32 Mouse[2];
    int    PrevMouseX[2];
    int    PrevMouseY[2];
    struct ClipData Clip [2];

    int     PreviousLineBackdropChanged;

    uint32 Mode7CharPaletteMask[256];
    int16  Mode7CharDirtyFlagCount = 0;
    uint8  Mode7CharDirtyFlag [256];
    uint32 Mode7PaletteDirtyFlag;
    uint8  Mode7Prepared;
    uint8  Mode7EXTBGFlag;

    bool   Mode7CharUsed [256];
    bool   Mode7CharUsedValid = false;

    bool                            WindowingEnabled;               
    VerticalSections                BrightnessSections;
    VerticalSections                BackdropColorSections;      // Palette color = 0.
    VerticalSections                FixedColorSections;         // Fixed color for color math / subscreen backdrop.
    VerticalSections                WindowLRSections;           // W1/W2 Left/Right

    int                             HiresFlip; 

    // Screen colors for Mode 7 Ext BG
    //
    uint16 Mode7ScreenColors[256];
    uint16 Mode7ScreenColors128[256];

    // Per-frame bitmasks for 4-color BG palette subsets updated via HDMA.
    // [bank] uses bit [pal] where bank = startPalette >> 5 and pal is 0-15.
    uint16 HDMAPalette4BGMask[4];
    uint16 HDMAPalette16Mask;

    // Added for register change optimization.
    // Helps in reducing number of FLUSH_REDRAWs per frame.
    //
    int                             DeferredRegisterWrite[0x100];    
};

struct SOBJ
{
    short  HPos;
    uint16 VPos;
    uint16 Name;
    uint8  VFlip;
    uint8  HFlip;
    uint8  Priority;
    uint8  Palette;
    uint8  Size;
};

struct SPPU {
    uint8  BGMode;
    uint8  BG3Priority;
    uint8  Brightness;

    struct {
	bool8 High;
	uint8 Increment;
	uint16 Address;
	uint16 Mask1;
	uint16 FullGraphicCount;
	uint16 Shift;
    } VMA;

    struct {
	uint16 SCBase;
	uint16 VOffset;
	uint16 HOffset;
	uint8 BGSize;
	uint16 NameBase;
	uint16 SCSize;
    } BG [4];

    bool8  CGFLIP;
    uint16 CGDATA [256]; 
    uint8  FirstSprite;
    uint8  LastSprite;
    struct SOBJ OBJ [128];
    uint8  OAMPriorityRotation;
    uint16 OAMAddr;
    uint8  RangeTimeOver;

    uint8  OAMFlip;
    uint16 OAMTileAddress;
    uint16 IRQVBeamPos;
    uint16 IRQHBeamPos;
    uint16 VBeamPosLatched;
    uint16 HBeamPosLatched;

    uint8  HBeamFlip;
    uint8  VBeamFlip;
    uint8  HVBeamCounterLatched;

    short  MatrixA;
    short  MatrixB;
    short  MatrixC;
    short  MatrixD;
    short  CentreX;
    short  CentreY;
    uint8  Joypad1ButtonReadPos;
    uint8  Joypad2ButtonReadPos;

    uint8  CGADD;
    uint8  FixedColourRed;
    uint8  FixedColourGreen;
    uint8  FixedColourBlue;
    uint16 SavedOAMAddr;
    uint16 ScreenHeight = 0;
    uint32 WRAM;
    uint8  BG_Forced;
    bool8  ForcedBlanking;
    bool8  OBJThroughMain;
    bool8  OBJThroughSub;
    uint8  OBJSizeSelect;
    uint16 OBJNameBase;
    bool8  OBJAddition;
    uint8  OAMReadFlip;
    uint8  OAMData [512 + 32];
    bool8  VTimerEnabled;
    bool8  HTimerEnabled;
    short  HTimerPosition;
    uint8  Mosaic;
    bool8  BGMosaic [4];
    bool8  Mode7HFlip;
    bool8  Mode7VFlip;
    uint8  Mode7Repeat;
    uint8  Window1Left;
    uint8  Window1Right;
    uint8  Window2Left;
    uint8  Window2Right;
    uint8  ClipCounts [6];
    uint8  ClipWindowOverlapLogic [6];
    uint8  ClipWindow1Enable [6];
    uint8  ClipWindow2Enable [6];
    bool8  ClipWindow1Inside [6];
    bool8  ClipWindow2Inside [6];
    bool8  RecomputeClipWindows;
    uint8  CGFLIPRead;
    uint16 OBJNameSelect;
    bool8  Need16x8Mulitply;
    uint8  Joypad3ButtonReadPos;
    uint8  MouseSpeed[2];

    // XXX Do these need to be added to snapshot.cpp?
    uint16 OAMWriteRegister;
    uint8 BGnxOFSbyte;
    uint8 OpenBus1;
    uint8 OpenBus2;

    // Added for OBJ drawing optimization
    //
    int PriorityDrawFromSprite = -1;

};

#define CLIP_OR 0
#define CLIP_AND 1
#define CLIP_XOR 2
#define CLIP_XNOR 3

struct SDMA {
    bool8  TransferDirection;
    bool8  AAddressFixed;
    bool8  AAddressDecrement;
    uint8  TransferMode;

    uint8  ABank;
    uint16 AAddress;
    uint16 Address;
    uint8  BAddress;

    // General DMA only:
    uint16 TransferBytes;

    // H-DMA only:
    bool8  HDMAIndirectAddressing;
    uint16 IndirectAddress;
    uint8  IndirectBank;
    uint8  Repeat;
    uint8  LineCount;
    uint8  FirstLine;
};

START_EXTERN_C
void S9xFlushDeferredLayers();
void S9xUpdateScreen ();
void S9xInitializeVerticalSections();
void S9xResetPPU ();
void S9xSoftResetPPU ();
void S9xFixColourBrightness ();
void S9xUpdateJoypads ();
void S9xProcessMouse(int which1);
void S9xSuperFXExec ();

void S9xSetPPU (uint8 Byte, uint16 Address);
uint8 S9xGetPPU (uint16 Address);
void S9xSetCPU (uint8 Byte, uint16 Address);
uint8 S9xGetCPU (uint16 Address);

void S9xInitC4 ();
void S9xSetC4 (uint8 Byte, uint16 Address);
uint8 S9xGetC4 (uint16 Address);
void S9xSetC4RAM (uint8 Byte, uint16 Address);
uint8 S9xGetC4RAM (uint16 Address);

extern struct SPPU PPU;
extern struct SDMA DMA [8];
extern struct InternalPPU IPPU;
END_EXTERN_C

#include "gfx.h"
#include "memmap.h"

typedef struct{
	uint8 _5C77;
	uint8 _5C78;
	uint8 _5A22;
} SnesModel;

START_EXTERN_C
extern SnesModel* Model;
extern SnesModel M1SNES;
extern SnesModel M2SNES;
END_EXTERN_C

#define MAX_5C77_VERSION 0x01
#define MAX_5C78_VERSION 0x03
#define MAX_5A22_VERSION 0x02


//#define DEBUG_FLUSH_REDRAW(a,b)   if (IPPU.PreviousLine != IPPU.CurrentLine && IPPU.RenderThisFrame) { printf ("FD: %04x <- %02x @ Y=%d\n", a, b, IPPU.CurrentLine); } else { printf ("    %04x <- %02x @ Y=%d\n", a, b, IPPU.CurrentLine); }
#define DEBUG_FLUSH_REDRAW(a,b)

struct LayerRenderState {
    bool   allowDefer;                  // true only during a REGISTER_2122 FLUSH
    uint16 changedPalette16Mask;        // palette-16 windows mutated since last FLUSH
    uint32 startY[5];                   // per-layer next-line-to-render cursor
    bool   shouldRenderThisSegment[5];  // gate decision this segment
    uint32 resetFrame;                  // last frame the cursors were reset
};
extern struct LayerRenderState LayerRender;

STATIC inline uint8 REGISTER_4212()
{
    GetBank = 0;
    if (CPU.V_Counter >= PPU.ScreenHeight + FIRST_VISIBLE_LINE &&
	CPU.V_Counter < PPU.ScreenHeight + FIRST_VISIBLE_LINE + 3)
	GetBank = 1;

    GetBank |= CPU.Cycles >= Settings.HBlankStart ? 0x40 : 0;
    if (CPU.V_Counter >= PPU.ScreenHeight + FIRST_VISIBLE_LINE)
	GetBank |= 0x80; /* XXX: 0x80 or 0xc0 ? */

    return (GetBank);
}

STATIC inline void FLUSH_REDRAW ()
{
    if (IPPU.RenderThisFrame)
    {
        if (IPPU.PreviousLine != IPPU.CurrentLine) {
            S9xUpdateScreenHardware();
        } else if (!LayerRender.allowDefer) {
            // Same-scanline non-$2122 flush: drain any still-deferred layers
            // before a silent register update corrupts their catch-up state.
            S9xFlushDeferredLayers();
        }
    }
}

STATIC inline void REGISTER_2104 (uint8 byte)
{
    if (PPU.OAMAddr & 0x100)
    {
        int addr = ((PPU.OAMAddr & 0x10f) << 1) + (PPU.OAMFlip & 1);
        if (byte != PPU.OAMData [addr]){
            DEBUG_FLUSH_REDRAW(0x2104, byte); FLUSH_REDRAW ();
            PPU.OAMData [addr] = byte;
            IPPU.OBJChanged = TRUE;

            // X position high bit, and sprite size (x4)
            struct SOBJ *pObj = &PPU.OBJ [(addr & 0x1f) * 4];

            pObj->HPos = (pObj->HPos & 0xFF) | SignExtend[(byte >> 0) & 1];
            pObj++->Size = byte & 2;
            pObj->HPos = (pObj->HPos & 0xFF) | SignExtend[(byte >> 2) & 1];
            pObj++->Size = byte & 8;
            pObj->HPos = (pObj->HPos & 0xFF) | SignExtend[(byte >> 4) & 1];
            pObj++->Size = byte & 32;
            pObj->HPos = (pObj->HPos & 0xFF) | SignExtend[(byte >> 6) & 1];
            pObj->Size = byte & 128;
        }
        PPU.OAMFlip ^= 1;
		if(!(PPU.OAMFlip & 1)){
			++PPU.OAMAddr;
			PPU.OAMAddr &= 0x1ff;
			if (PPU.OAMPriorityRotation && PPU.FirstSprite != (PPU.OAMAddr >> 1))
			{
				PPU.FirstSprite = (PPU.OAMAddr&0xFE) >> 1;
				IPPU.OBJChanged = TRUE;
			}
		} else {
			if (PPU.OAMPriorityRotation && (PPU.OAMAddr&1)) IPPU.OBJChanged = TRUE;
		}
    } else if(!(PPU.OAMFlip & 1)){
        PPU.OAMWriteRegister &= 0xff00;
        PPU.OAMWriteRegister |= byte;
        PPU.OAMFlip |= 1;
		if (PPU.OAMPriorityRotation && (PPU.OAMAddr&1)) IPPU.OBJChanged = TRUE;
    } else {
        PPU.OAMWriteRegister &= 0x00ff;
        uint8 lowbyte = (uint8)(PPU.OAMWriteRegister);
        uint8 highbyte = byte;
        PPU.OAMWriteRegister |= byte << 8;

        int addr = (PPU.OAMAddr << 1);

        if (lowbyte != PPU.OAMData [addr] ||
            highbyte != PPU.OAMData [addr+1])
        {
            DEBUG_FLUSH_REDRAW(0x2104, byte); FLUSH_REDRAW ();
            PPU.OAMData [addr] = lowbyte;
            PPU.OAMData [addr+1] = highbyte;
            IPPU.OBJChanged = TRUE;
            if (addr & 2)
            {
                // Tile
                PPU.OBJ[addr = PPU.OAMAddr >> 1].Name = PPU.OAMWriteRegister & 0x1ff;

                // priority, h and v flip.
                PPU.OBJ[addr].Palette = (highbyte >> 1) & 7;
                PPU.OBJ[addr].Priority = (highbyte >> 4) & 3;
                PPU.OBJ[addr].HFlip = (highbyte >> 6) & 1;
                PPU.OBJ[addr].VFlip = (highbyte >> 7) & 1;
            }
            else
            {
                // X position (low)
                PPU.OBJ[addr = PPU.OAMAddr >> 1].HPos &= 0xFF00;
                PPU.OBJ[addr].HPos |= lowbyte;

                // Sprite Y position
                PPU.OBJ[addr].VPos = highbyte;
            }
        }
        PPU.OAMFlip &= ~1;
        ++PPU.OAMAddr;
		if (PPU.OAMPriorityRotation && PPU.FirstSprite != (PPU.OAMAddr >> 1))
		{
			PPU.FirstSprite = (PPU.OAMAddr&0xFE) >> 1;
			IPPU.OBJChanged = TRUE;
		}
    }

    Memory.FillRAM [0x2104] = byte;
}

#define COMPARE_WRITE_VRAM(addr, data) if (Memory.VRAM[(addr)] != data) { notEqual = true; Memory.VRAM[(addr)] = data; }


STATIC inline void REGISTER_2118 (uint8 Byte)
{
    uint32 address;
    bool notEqual = false;

    if (PPU.VMA.FullGraphicCount)
    {
        uint32 rem = PPU.VMA.Address & PPU.VMA.Mask1;
        address = (((PPU.VMA.Address & ~PPU.VMA.Mask1) +
                (rem >> PPU.VMA.Shift) +
                ((rem & (PPU.VMA.FullGraphicCount - 1)) << 3)) << 1) & 0xffff;

        //Memory.VRAM [address] = Byte;
        COMPARE_WRITE_VRAM(address, Byte);
    }
    else
    {
	    //Memory.VRAM[address = (PPU.VMA.Address << 1) & 0xFFFF] = Byte;
        COMPARE_WRITE_VRAM(address = (PPU.VMA.Address << 1) & 0xFFFF, Byte);
    }

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            /*if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //    printf ("2118 m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
            }
            else*/
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;

                gpu3dsSetMode7TileModified(tileIdx, Byte);
                IPPU.Mode7CharUsed[Byte] = true;

                //if (Byte != 0)
                //    printf ("2118 m7 idx=%x, byte=%x \n", tileIdx, Byte);
            }
        }
    }

    if (!PPU.VMA.High)
    {
#ifdef DEBUGGER
        if (Settings.TraceVRAM && !CPU.InDMA)
        {
            printf ("VRAM write byte: $%04X (%d,%d)\n", PPU.VMA.Address,
                Memory.FillRAM[0x2115] & 3,
                (Memory.FillRAM [0x2115] & 0x0c) >> 2);
        }
#endif	
	    PPU.VMA.Address += PPU.VMA.Increment;
    }
//    Memory.FillRAM [0x2118] = Byte;
}

STATIC inline void REGISTER_2118_tile (uint8 Byte)
{
    uint32 address;
    bool notEqual = false;

    uint32 rem = PPU.VMA.Address & PPU.VMA.Mask1;
    address = (((PPU.VMA.Address & ~PPU.VMA.Mask1) +
		 (rem >> PPU.VMA.Shift) +
		 ((rem & (PPU.VMA.FullGraphicCount - 1)) << 3)) << 1) & 0xffff;
    
    //Memory.VRAM [address] = Byte;
    COMPARE_WRITE_VRAM(address, Byte);

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            /*if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //printf ("2118 t m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
                
            }
            else*/
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;

                gpu3dsSetMode7TileModified(tileIdx, Byte);
                IPPU.Mode7CharUsed[Byte] = true;

                //if (Byte != 0)
                //    printf ("2118 t m7 idx=%x, byte=%x \n", tileIdx, Byte);
            }
        }
    }

    if (!PPU.VMA.High)
	PPU.VMA.Address += PPU.VMA.Increment;
//    Memory.FillRAM [0x2118] = Byte;
}

STATIC inline void REGISTER_2118_linear (uint8 Byte)
{
    uint32 address;
    bool notEqual = false;

    //Memory.VRAM[address = (PPU.VMA.Address << 1) & 0xFFFF] = Byte;
    address = (PPU.VMA.Address << 1) & 0xFFFF;
    COMPARE_WRITE_VRAM(address, Byte);

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            /*if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //printf ("2118 l m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
            }
            else*/
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;
                
                gpu3dsSetMode7TileModified(tileIdx, Byte);
                IPPU.Mode7CharUsed[Byte] = true;

                //if (Byte != 0)
                //    printf ("2118 l m7 idx=%x, byte=%x \n", tileIdx, Byte);
            }
        }
    }

    if (!PPU.VMA.High)
	    PPU.VMA.Address += PPU.VMA.Increment;
//    Memory.FillRAM [0x2118] = Byte;
}

STATIC inline void REGISTER_2119 (uint8 Byte)
{
    uint32 address;
    bool notEqual = false;
    
    if (PPU.VMA.FullGraphicCount)
    {
        uint32 rem = PPU.VMA.Address & PPU.VMA.Mask1;
        address = ((((PPU.VMA.Address & ~PPU.VMA.Mask1) +
                (rem >> PPU.VMA.Shift) +
                ((rem & (PPU.VMA.FullGraphicCount - 1)) << 3)) << 1) + 1) & 0xFFFF;
        
        //Memory.VRAM [address] = Byte;
        COMPARE_WRITE_VRAM(address, Byte);
    }
    else
    {
	    //Memory.VRAM[address = ((PPU.VMA.Address << 1) + 1) & 0xFFFF] = Byte;
        address = ((PPU.VMA.Address << 1) + 1) & 0xFFFF;
        COMPARE_WRITE_VRAM(address, Byte);
    }

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            //if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //printf ("2119 m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
            }
            /*else
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;
                
                gpu3dsSetMode7TileModified(tileIdx, Byte);

                //if (Byte != 0)
                //    printf ("2119 m7 idx=%x, byte=%x \n", tileIdx, Byte);
            }*/
        }
    }

    if (PPU.VMA.High)
    {
#ifdef DEBUGGER
        if (Settings.TraceVRAM && !CPU.InDMA)
        {
            printf ("VRAM write word: $%04X (%d,%d)\n", PPU.VMA.Address,
                Memory.FillRAM[0x2115] & 3,
                (Memory.FillRAM [0x2115] & 0x0c) >> 2);
        }
#endif	
	    PPU.VMA.Address += PPU.VMA.Increment;
    }
//    Memory.FillRAM [0x2119] = Byte;
}

STATIC inline void REGISTER_2119_tile (uint8 Byte)
{
    bool notEqual = false;
    
    uint32 rem = PPU.VMA.Address & PPU.VMA.Mask1;
    uint32 address = ((((PPU.VMA.Address & ~PPU.VMA.Mask1) +
		    (rem >> PPU.VMA.Shift) +
		    ((rem & (PPU.VMA.FullGraphicCount - 1)) << 3)) << 1) + 1) & 0xFFFF;
    
    //Memory.VRAM [address] = Byte;
    COMPARE_WRITE_VRAM(address, Byte);

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            //if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //printf ("2119 t m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
            }
            /*else
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;
                
                gpu3dsSetMode7TileModified(tileIdx, Byte);

                //if (Byte != 0)
                //    printf ("2119 t m7 idx=%x, byte=%x\n", tileIdx, Byte);
            }*/
        }
    }

    if (PPU.VMA.High)
	    PPU.VMA.Address += PPU.VMA.Increment;
//    Memory.FillRAM [0x2119] = Byte;
}

STATIC inline void REGISTER_2119_linear (uint8 Byte)
{
    uint32 address;
    bool notEqual = false;
    
    //Memory.VRAM[address = ((PPU.VMA.Address << 1) + 1) & 0xFFFF] = Byte;
    address = ((PPU.VMA.Address << 1) + 1) & 0xFFFF;
    COMPARE_WRITE_VRAM(address, Byte);

    if (notEqual)
    {
        IPPU.TileCached [TILE_2BIT][address >> 4] = FALSE;
        IPPU.TileCached [TILE_4BIT][address >> 5] = FALSE;
        IPPU.TileCached [TILE_8BIT][address >> 6] = FALSE;

        if (address < 32768)
        {
            //if (address & 1)
            {
                IPPU.Mode7CharDirtyFlag[address >> 7] = 2;
                IPPU.Mode7CharDirtyFlagCount = 1;
                //if (Byte != 0)
                //printf ("2119 l m7 ch=%x a=%x byte=%x\n", address >> 7, address >> 1, Byte);
            }
            /*else
            {
                int tileIdx = address >> 1;
                if (IPPU.Mode7CharDirtyFlag[Byte] == 2)
                    IPPU.Mode7CharDirtyFlagCount = 1;
                
                gpu3dsSetMode7TileModified(tileIdx, Byte);

                //if (Byte != 0)
                //    printf ("2119 l m7 idx=%x, byte=%x\n", tileIdx, Byte);
            }*/
        }
    }

    if (PPU.VMA.High)
	    PPU.VMA.Address += PPU.VMA.Increment;
//    Memory.FillRAM [0x2119] = Byte;
}


STATIC inline void REGISTER_2122(uint8 Byte)
{
    uint8 cgaddr = PPU.CGADD;
    uint16* cgdata = &PPU.CGDATA[cgaddr];
    const bool isHighByte = PPU.CGFLIP;
    bool changed = false;

    if (isHighByte)
    {
        const uint16 newVal = (Byte & 0x7F) << 8;
        if (newVal != (*cgdata & 0x7F00))
        {
            *cgdata = (*cgdata & 0x00FF) | newVal;
            changed = true;
            
            if (SNESGameFixes.PaletteCommitLine == -2 && cgaddr != 0)
            {
                LayerRender.changedPalette16Mask |= (uint16)(1u << (cgaddr >> 4));
                LayerRender.allowDefer = true;
                FLUSH_REDRAW();
                LayerRender.allowDefer = false;
            }
        }
        PPU.CGADD++;
    }
    else 
    {
        if (Byte != (uint8)(*cgdata & 0xFF))
        {
            *cgdata = (*cgdata & 0x7F00) | Byte;
            changed = true;
            
            if (SNESGameFixes.PaletteCommitLine == -2 && cgaddr != 0)
            {
                LayerRender.changedPalette16Mask |= (uint16)(1u << (cgaddr >> 4));
                LayerRender.allowDefer = true;
                FLUSH_REDRAW();
                LayerRender.allowDefer = false;
            }
        }
    }

    if (!changed) {
        PPU.CGFLIP ^= 1;
        return;
    }

    IPPU.Mode7PaletteDirtyFlag |= 1 << (cgaddr >> 3);
    IPPU.ColorsChanged = TRUE;

    if (SNESGameFixes.PaletteCommitLine >= 0)
    {
        if (cgaddr == 0)
        {
            S9xUpdateVerticalSectionValue(&IPPU.BackdropColorSections,
                BUILD_PIXEL(IPPU.XB[*cgdata & 0x1F],
                          IPPU.XB[(*cgdata >> 5) & 0x1F],
                          IPPU.XB[(*cgdata >> 10) & 0x1F]));
        }
        PPU.CGFLIP ^= 1;
        return;
    }

    const uint16 oldScreenColor = IPPU.ScreenColors[cgaddr];
    const uint16 color = *cgdata;
    IPPU.Red[cgaddr] = IPPU.XB[color & 0x1F];
    IPPU.Green[cgaddr] = IPPU.XB[(color >> 5) & 0x1F];
    IPPU.Blue[cgaddr] = IPPU.XB[(color >> 10) & 0x1F];
    IPPU.ScreenColors[cgaddr] = BUILD_PIXEL(
        IPPU.Red[cgaddr],
        IPPU.Green[cgaddr],
        IPPU.Blue[cgaddr]
    );
    const uint16 newScreenColor = IPPU.ScreenColors[cgaddr];

    if (newScreenColor != oldScreenColor)
    {
        S9xUpdatePaletteHashesForCgaddr(cgaddr, oldScreenColor, newScreenColor);

        if (IPPU.InHDMA)
        {
            IPPU.HDMAAnyCGRAMTouched = TRUE;
            IPPU.HDMAPalette16Mask |= (1 << (cgaddr >> 4));
            if (cgaddr < 128)
                IPPU.HDMAPalette4BGMask[cgaddr >> 5] |= (1 << ((cgaddr & 0x1F) >> 2));
        }
    }

    if (cgaddr == 0)
        S9xUpdateVerticalSectionValue(&IPPU.BackdropColorSections, IPPU.ScreenColors[0]);

    PPU.CGFLIP ^= 1;
}

STATIC inline void REGISTER_2180(uint8 Byte)
{
    Memory.RAM[PPU.WRAM++] = Byte;
    PPU.WRAM &= 0x1FFFF;
    Memory.FillRAM [0x2180] = Byte;
}


//Platform specific input functions used by PPU.CPP
void JustifierButtons(uint32&);
bool JustifierOffscreen();



#endif

