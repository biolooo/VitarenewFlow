#include "copyright.h"

#include <stdio.h>



#ifndef _BSX_H_
#define _BSX_H_

struct SBSX
{
	bool8	dirty;			// Changed register values
	bool8	dirty2;			// Changed register values
	bool8	bootup;			// Start in bios mapping
	bool8	flash_enable;	// Flash state
	bool8	write_enable;	// ROM write protection
	bool8	read_enable;	// Allow card vendor reading
	uint32	flash_command;	// Flash command
	uint32	old_write;		// Previous flash write address
	uint32	new_write;		// Current flash write address
	uint8	out_index;
	uint8	output[32];
	uint8	PPU[32];
	uint8	MMC[16];
	uint8	prevMMC[16];
	uint8	test2192[32];

	bool	strm1_1st;
	bool	strm2_1st;
	int		strm1_num;
	int		strm2_num;

	FILE	*stream1;
	FILE	*stream2;

	bool	flash_csr;
	bool	flash_gsr;
	bool	flash_bsr;
	bool	flash_cmd_done;  
};

extern struct SBSX	BSX;

uint8 S9xGetBSX (uint32);
void S9xSetBSX (uint8, uint32);
uint8 S9xGetBSXPPU (uint16);
void S9xSetBSXPPU (uint8, uint16);
uint8 * S9xGetBasePointerBSX (uint32);
void S9xInitBSX (void);
void S9xResetBSX (void);
void S9xBSXPostLoadState (void);
uint8 S9xBSXGetRTC (void);
void S9xBSXSetStream1 (uint8);
void S9xBSXSetStream2 (uint8);

#endif
