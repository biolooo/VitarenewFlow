void apply_patches();
