# YattLib-3D
YattLib-3D is a convenience library for homebrew 3DS development, written in the C language.

## Dependencies
YattLib-3D depends on [libctru](https://github.com/devkitPro/libctru) and the C standard library.

## How To Use
Add the `src` directory to your sources path and the `include` directory to your include path. Examples can be found in the `examples` directory.

## Contributing
PRs, issues, contacting me, etc are welcome.

## TODO
- Write nice documentation.
- Create tests. Full integration tests will probably be necessary.
- Create buildable examples.
