// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 VitarenewFlow contributors
#pragma once
#include <3ds.h>
Result ds_prepare_launch(const char *rom);
#define DS_BOOTSTRAP_ID 0x0004800546574452ULL
Result ds_install_bootstrap(void (*progress)(float));

Result ds_install_bootstrap_file(const char *path,void (*progress)(float));
