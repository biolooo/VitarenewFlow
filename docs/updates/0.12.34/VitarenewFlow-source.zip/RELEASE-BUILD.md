# Build this exact source package

Use the devkitARM linux/amd64 chroot pinned in docs/PC2-SETUP.md, with host
GCC/UBSan, Python and zlib1g-dev. Extract this ZIP into a NEW directory inside
that chroot (never over an existing SDK project). Enter it with chroot.
From the extracted root, flatten only the archived release fixtures for the
existing stage runner, then execute:

```sh
cp -a tests/release-0.12.33/. tests/
cp scripts/check-fixture-source.py check-fixture-source.py
cp scripts/verify-stage.sh verify-stage.sh
bash verify-stage.sh
```

The stage script sets DEVKITPRO/DEVKITARM/PATH, builds launcher/3ds-library.3dsx
and .smdh and runs real-source anchors, UI/banner and existing hostfixtures.
verify-local.sh is for the complete repository: its package-integrity inventory
requires the separate historical docs/updates distributions omitted from this ZIP.
No SDK, emulator binaries, ROMs, saves, keys or private music are in this package.
The three launcher/tools font input/generator files are retained unchanged from
the .33 source archive; the checked-in font header is used for this build.
