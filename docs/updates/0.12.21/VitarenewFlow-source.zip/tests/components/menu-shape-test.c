#include "settings_menu.h"
#include <assert.h>
#include <stdio.h>
int main(void){const MenuAction expected[]={MENU_SCAN,MENU_DS,MENU_COMPONENTS,MENU_DESKTOP};assert(settings_menu_count(MENU_GAMES)==4);for(unsigned i=0;i<4;i++){const MenuItem *m=settings_menu_item(MENU_GAMES,i);assert(m&&m->label&&m->detail&&m->action==expected[i]);assert(settings_menu_hit(100,54+46*i+10,MENU_GAMES)==(int)i);}assert(!settings_menu_item(MENU_GAMES,4));puts("PASS: actual games menu has four accessible actions including emulator and desktop downloads; no count/array mismatch");}
