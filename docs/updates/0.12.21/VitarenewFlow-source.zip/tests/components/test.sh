set -eu
ROOT=/home/maxim/codex-3ds-work/toolchain
TASK=/mnt/c/Users/subje/Documents/Codex/2026-10-13/kan
mkdir -p "$ROOT/desktop-test"
cp "$TASK/work/desktop-v01221/transaction-test.c" "$TASK/work/desktop-v01221/input-test.c" "$TASK/work/desktop-v01221/menu-shape-test.c" "$ROOT/desktop-test/"
cp "$TASK/outputs/3ds-library/source/components.h" "$TASK/outputs/3ds-library/source/component_catalog.h" "$TASK/outputs/3ds-library/source/settings_menu.h" "$TASK/outputs/3ds-library/source/settings_menu.c" "$ROOT/desktop-test/"
chroot "$ROOT" /bin/bash -c 'cd /desktop-test; gcc -std=c11 -Wall -Wextra -Werror -fsanitize=undefined transaction-test.c -o transaction-test; ./transaction-test; gcc -std=c11 -Wall -Wextra -Werror -fsanitize=undefined input-test.c -o input-test; ./input-test; gcc -std=c11 -Wall -Wextra -Werror -fsanitize=undefined menu-shape-test.c settings_menu.c -o menu-shape-test; ./menu-shape-test'
