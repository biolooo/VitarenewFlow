#include <stdbool.h>
#include <assert.h>
#include <stdio.h>
#include "components.h"
enum{KEY_A=1,KEY_B=2,KEY_L=4,KEY_R=8,KEY_UP=16,KEY_DOWN=32,KEY_TOUCH=64};
static bool componentPage=true,installing;static unsigned componentSelected,starts,cancels,commits;static ComponentState state;
static ComponentDef defs[7]={{"GB","",0,4},{"DS","",0,4},{"N64","",0,4},{"SNES","",0,0},{"NES","",0,0},{"VB","",0,0},{"Desktop","",0,4}};
const ComponentDef *component_definition(unsigned n){return &defs[n];}
ComponentStatus components_status(void){ComponentStatus s={.state=state};return s;}
void components_cancel(void){cancels++;state=COMP_CANCELLED;}
void components_clear(void){state=COMP_IDLE;}
void components_start(unsigned n){if(defs[n].count){starts++;state=COMP_DOWNLOAD;}}
bool components_commit(void){assert(installing);commits++;state=COMP_DONE;return true;}
static void app_update_stop(void){}
static bool aptIsHomeAllowed(void){return true;}static bool aptIsSleepAllowed(void){return true;}
static void aptSetHomeAllowed(bool b){(void)b;}static void aptSetSleepAllowed(bool b){(void)b;}
static const char *tr(const char*s){return s;}static void draw(bool a,float b,const char*c){(void)a;(void)b;(void)c;}
static void input(unsigned keys,int x,int y){struct{int px,py;}pos={x,y};
            ComponentStatus cs=components_status();bool busy=cs.state==COMP_DOWNLOAD||cs.state==COMP_READY;
            if(cs.state==COMP_READY){bool home=aptIsHomeAllowed(),sleep=aptIsSleepAllowed();installing=true;aptSetHomeAllowed(false);aptSetSleepAllowed(false);draw(true,0,tr("Emulator wird eingerichtet"));components_commit();installing=false;aptSetHomeAllowed(home);aptSetSleepAllowed(sleep);}
            else if(keys&KEY_B || ((keys&KEY_TOUCH)&&((pos.py<44&&pos.px>=276)||(busy&&pos.py>=192)||(componentSelected==6&&pos.py>=201&&pos.py<231&&pos.px<94)))){if(busy)components_cancel();else componentPage=false;}
            else if(!busy){
                if(keys&(KEY_L|KEY_R|KEY_UP|KEY_DOWN|KEY_TOUCH))components_clear();
                if(componentSelected!=6&&((keys&KEY_L)||((keys&KEY_TOUCH)&&pos.py>=201&&pos.px<94)))componentSelected=componentSelected<3?3:0;
                if(componentSelected!=6&&(keys&KEY_R))componentSelected=componentSelected<3?3:0;
                if(componentSelected!=6&&(keys&KEY_UP))componentSelected=componentSelected?componentSelected-1:5;
                if(componentSelected!=6&&(keys&KEY_DOWN))componentSelected=(componentSelected+1)%6;
                if(componentSelected!=6&&(keys&KEY_TOUCH)&&pos.py>=54&&pos.py<174){unsigned row=(pos.py-54)/40;componentSelected=(componentSelected/3)*3+row;}
                if(keys&KEY_A || ((keys&KEY_TOUCH)&&pos.py>=201&&pos.py<231&&pos.px>=104)){app_update_stop();components_start(componentSelected);}
            }
}

int main(void){state=COMP_IDLE;input(KEY_TOUCH,40,215);assert(componentSelected==3&&!starts);input(KEY_A,0,0);assert(!starts);input(KEY_L,0,0);assert(componentSelected==0);input(KEY_TOUCH,130,105);assert(componentSelected==1&&!starts);input(KEY_TOUCH,190,215);assert(starts==1&&state==COMP_DOWNLOAD);input(KEY_DOWN,0,0);assert(componentSelected==1);input(KEY_TOUCH,160,210);assert(cancels==1&&state==COMP_CANCELLED);state=COMP_READY;input(0,0,0);assert(commits==1&&!installing&&state==COMP_DONE);input(KEY_B,0,0);assert(!componentPage);componentPage=true;state=COMP_IDLE;componentSelected=6;input(KEY_L|KEY_R|KEY_UP|KEY_DOWN,0,0);assert(componentSelected==6);input(KEY_TOUCH,100,105);assert(componentSelected==6);input(KEY_A,0,0);assert(starts==2);state=COMP_DONE;input(KEY_TOUCH,40,215);assert(!componentPage);puts("PASS: actual emulator page input, touch selection, page switch, install, unavailable package, touch cancel, input lock and commit guard");}
