# Build this exact 0.12.40 source package

Use linux/amd64 devkitpro/devkitarm at the immutable image digest
sha256:15b79ce75822c289538d8153da5fa7aafe5e6adc32ad8a575a197beca0f0761b.
The .40 CI build uses this exact container with host gcc/g++, make, Python 3
and zlib1g-dev installed only in its ephemeral layer. The native SDK and 3DS
libraries remain those in the pinned image. A matching existing chroot is also
possible (docs/PC2-SETUP.md). Extract into a NEW isolated directory, never over
an existing SDK project, then enter that directory inside the container/chroot.
The native receiver endpoint is already included in launcher/source/report_transport.h;
changing it changes the application and requires a new build/verification.

Flatten only the archived historical release fixtures for the current stage runner:

```sh
cp -a tests/release-0.12.33/. tests/
cp scripts/check-fixture-source.py check-fixture-source.py
cp scripts/verify-stage.sh verify-stage.sh
bash verify-stage.sh
```

Keep tests/title-cache, tests/ds-library, tests/error-report, tests/update-notes, tests/report-transport and tests/backlog
in place: they are current root-relative tests, not additional fixtures to flatten.
Keep release-notes/0.12.40.json and scripts/generate-release-notes.py in place too.
The stage runner checks the generated installed header against this JSON and
validates its generated notes.txt with the actual C parser before the build.
Do not regenerate a different header or replace the JSON to make a mismatch pass.
The stage script sets DEVKITPRO/DEVKITARM/PATH and builds launcher/3ds-library.3dsx and .smdh.
Compare both artifacts byte-for-byte with the delivered files before accepting
reproducibility. No real console, WLAN, HOME/POWER OS transfer or NAND is tested.

The full repository's verify-local.sh also inventories separate historical emulator
distributions under docs/updates, intentionally omitted from this source-only ZIP.
Use the stage runner above for this package rather than claiming that inventory
passed with missing distributions.

Receiver tests use temporary SQLite databases and loopback sockets only:
`python3 -m unittest discover -s receiver/error-reports -p test_server.py -v`.
Receiver deployment, TLS/proxy configuration and a real stored HTTPS report need
separate operator validation. Never expose a database/admin endpoint or copy an
existing deployment's data directory into this package.

Font generator and original licensed input are retained unchanged from the .33
source archive if absent from the checkout; the supplied font header is used.
No SDK, private media, report database, ROM, save, key or local account is bundled.
