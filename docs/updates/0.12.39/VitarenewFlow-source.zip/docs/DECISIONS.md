# Entscheidungen und Quellen

## DS-Dateisuche und leere Ansicht — 26.10.2026

Bestehende Dateistrukturen unterstützen statt Spiele umzusortieren. Standardwurzeln `/roms/nds`, `/nds`, `/games/nds` einschließlich Unterordnern; explizite zusätzliche Ordner erhalten Vorrang. Sichtbare Grenzen und Abbruch statt unbegrenzt blockierender Suche. Kein Schluss von leerer Liste auf defektes TWL-System. Eine globale Textsuche bleibt ein eigener Zustand. Initial keine neue Diagnoseübertragung oder Schemaänderung; Berichtsevidenz bleibt unklar, die Verbesserung folgt dem ausdrücklich beauftragten UX-/Suchauftrag. Keine automatische Veröffentlichung.


## X-Updateinfos — lokaler Entwicklungsstand 0.12.38

Nutzer meldete unzuverlässige X-Infos. Ursache: fest eingebaute Hinweise der installierten Version und deren Versionsliste bestimmten Darstellung/Zugänglichkeit. Ersetzt durch eigene X-/Touch-Infoseite mit Version, DE/EN-Hinweisen, Blättern und B/X-Rückkehr; keine Installationsaktion aus dieser Ansicht. Lange gültige Hinweise erhalten weitere Seiten anhand tatsächlicher Schriftmetriken. Kein Text einer anderen Version wird als Zielupdatehinweis ausgegeben; fehlende Hinweise werden klar angezeigt und verhindern OTA nicht.

Remote: unveränderliches `<Version>/notes.txt` (VFNOTES1), fester HTTPS-Pfad, exakte Versionsbindung, 1–3 DE/EN-Paare mit maximal120UTF8Bytes, Größen-/UTF8-/Steuerzeichenprüfung. Status/Version/Hinweise unter gemeinsamer Sperre, alte Daten beim Neucheck gelöscht. Bisheriges fünfzeiliges VFUPDATE1 bleibt für Altclients unverändert. .37 muss einmal aktualisiert werden, bevor es diese Remoteinfos künftiger Versionen lesen kann.

Gemeinsame Changelogquelle: `release-notes/<Version>.json`. Generator erstellt installierte Hinweise, Paketierung daraus README/FEATURES-DE und notes.txt; Build, Paketierung und Pages verweigern fehlende, veraltete oder falsche Versionshinweise. Alte manuelle Runtime-Versionslisten entfernt. Inhaltliche Stichpunkte werden weiterhin bewusst verfasst; automatische Erzeugung der Ausgabedateien ist umgesetzt. Release-Skill in Repository und persönlicher Installation angepasst.

Stand lokal, keine .38-Veröffentlichung, keine Konsolenabnahme. Öffentliche .37-Dateien/Kanäle bleiben unverändert. Basis84f7ae7, vor Beginn Remoteabgleich identisch. PC2-Arbeit nach letztem Push muss vor Integration erneut abgeglichen werden.

## Freigegebener Layoutrelease 0.12.37

Nutzer hat die Veröffentlichung der About-Layoutkorrektur ausdrücklich beauftragt. Änderungen: zentrierte übersichtliche Infokarte, Website und VitaRenew-Zeile untereinander, dezente eigene Reportzeile mit X-Tastenmarkierung. Touchflächen bleiben unverändert. Version 0.12.37, Desktop 0.4.1 unverändert. Native Prüfung und exaktes Quellpaket werden vor Veröffentlichung frisch geprüft; öffentliche Bytes danach separat bestätigt. Keine .37-Konsolenabnahme.

Wiederverwendbarer Release-Skill: `skills/flow-release/SKILL.md`, inklusive generischer öffentlicher Byteprüfung. Repositorykopie für PC 2; auf PC 1 zusätzlich unter dem persönlichen Codex-Skillpfad installiert. Der Skill ersetzt keine Nutzerfreigabe; die aktuelle Aufforderung autorisiert diesen Release ohne weitere Bestätigungsrunde. Changeloghinweise .37 werden weiterhin manuell DE/EN gepflegt; automatische Generierung bleibt offen.

## About-Layoutkorrektur nach .36 — lokal

Nutzer meldete gedrängte About-Seite nach Hinzufügen des Reportbuttons. Identität, Version, VitaRenew-Zeile und Website stehen nun zentriert untereinander in einer gemeinsamen Karte. Der Meldebutton verwendet eine dezente eigene Zeile mit X-Tastenmarkierung statt einer vollflächigen Akzentfläche. Keine gedrängte horizontale Website-/Textzeile mehr. Report-/Zurück-Touchflächen unverändert. DE/EN-Layoutvorschau mit Inter-Schrift und den nativen Glyphenvorschüben visuell geprüft; kein Konsolenscreenshot oder Hardwarepass. Öffentliche .36-Pakete unverändert, noch nicht veröffentlicht.

Changelog für nächsten Release: Über & Unterstützung mit klarer Textanordnung und dezenterem Meldebutton überarbeitet (EN: Refined About & support layout and report button). Gitbasis 46e69ee, Remote-main vor Beginn 2f4356c; kein neuer PC-2-Remotecommit. Nicht gepushte PC-2-Arbeit bleibt hier unsichtbar.

Reportauswertung eingerichtet (21.10.2026): aktive sechsstündliche Chat-Automation, lesender datensparsamer Gruppierer und lokale Fix-/Diagnosevorbereitung nach Evidenz. Details: [REPORT-TRIAGE](REPORT-TRIAGE.md). Kein automatisches Release/Push. Gesamttest auf neuer Konsole im STATUS-TODO, ausdrücklich noch nicht abgenommen.

## Reportverbesserung .36 — 21.10.2026

Nutzerauftrag: Reportzugang im passenden Menü, zusätzlicher Fallback bei unerwarteten Fehlern und Diagnose unabhängig vom Kommentar. Umsetzung verwendet begrenzte strukturierte RAM-Snapshots statt Rohlogs, um den Fehlerzeitpunkt zu erhalten und private Titel/Pfade auszuschließen. Regelmäßiger Zugang im Unterstützungsmenü; kritische Übergaben bleiben geschützt. Schema 2 ist im Receiver abwärtskompatibel, benötigt vor Clientfreigabe ein eigenes Deployment mit Nachweis. Lokale Implementierung ist keine Veröffentlichung oder Hardwareabnahme.

Backlogauftrag 21.10.2026: Startanimation einschließlich Toggle/Mindestwartezeit entfernt; die ausschließlich dafür verwendete alte appearance.txt wird erhalten und ignoriert. Fortschritts-/Seed-/HOME-Anzeigen und Originalbanner sind davon unabhängig. Updatehinweise stammen aus bekannten lokalen versionsgebundenen Daten, da VFUPDATE1 keine Release-Notes überträgt; keine spekulativen Hinweise zu neuen Remoteversionen. Nutzer vertagte N64 bis zu späteren Logs und beließ Save-/PC-Sync/Konvertierung/Modul-Saves offen. Hardwareabnahme und originale HOME-Musik bleiben offen. Nachweise: BACKLOG-WORK.md.

PC-2-Einrichtung 21.10.2026: SDK-Version aus der Übergabe beibehalten und per Digest geprüft als separaten Chroot in WSL2 eingerichtet. Ubuntu/SDK liegen auf E: wegen begrenztem Platz auf C:. Keine SDK-Aktualisierung und keine Übernahme privater PC-1-Daten. Nativer Build und Hostfixtures bestätigen lokale Entwicklungsfähigkeit, nicht Konsolenfunktion. Befehle/Nachweise: [PC2-SETUP.md](PC2-SETUP.md).

Status und Abnahme werden nur in [STATUS](STATUS.md) geführt; Quellvarianten nur in [MIGRATION](MIGRATION.md). Diese Liste erklärt das Warum. Chat-Zitate stammen aus dem im bisherigen Hauptchat sichtbaren Verlauf; ältere Versionsnummern sind teilweise nicht eindeutig zuzuordnen. Ein Release-README ist Autorenbericht, keine Nutzerabnahme.

| ID | Entscheidung / Begründung | Quelle und Status |
|---|---|---|
| D01 | Ein gemeinsamer moderner Launcher, Kategorien nach Herkunft; 3DS und Homebrew trennen; GB/GBC/GBA zusammenlegen. L/R vor/zurück, X Spielinfos. | Nutzer: „3DS spiele und Homebrew Apps“, „GBA, GBC und GB zusammen“, später „L/R und X funktionieren“. Implementiert in `library_model.*`, `home_controls.*`, `main.c`; ältere Version nicht eindeutig. |
| D02 | Moderne passende Oberfläche statt exakter HOME-Kopie; volle untere Fläche im Menü, keine Unterüberschriften/unnötige Steuerungsleiste. Originale animierte HOME-Banner oben für 3DS, große Cover für andere. | Nutzerantwort „Originales animiertes HOME-Menü-Banner“; später „Das neue Menü gefällt mir, alles funktioniert“. Umsetzung `ui.c`/Banner-Module; vollständige Banner-Erzeugung offen. |
| D03 | Name VitarenewFlow, Logo an VitaRenew, Variante C; Alpha-Fehler korrigieren, Supportbereich vitarenew.de, DE/EN. | Direkte Nutzerwahl, „Sprachwechsel funktioniert jetzt und alle Tests bestanden“. Branding/l10n/Support implementiert, spätere neue Dialoge separat abnehmen. |
| D04 | Eigener Code GPL-3.0-only; Fremdlizenzen separat erhalten. Keine ROMs, Saves, Keys oder Nintendo-Musik in öffentlichen Paketen. | Nutzer „GPL-3.0 verwenden“; LICENSE/NOTICES, Quellkopftexte. Verteilung der Emulatoren ersetzt keinen Lizenz-/Quellenreview. |
| D05 | Erst über Universal-Updater auf bereits gemoddeter Konsole installieren; sämtliche weitere Anpassungen/Emulatoren/Desktop-Download in der App. OTA ohne SD-Umstecken. | Nutzer „nur über den Universal updater installieren ... alle weitere anpassungen ... direkt in der app“, „Installation ... funktioniert, die App startet“, früher „Update ... super Funktioniert“. `components.*`, `app_update.*`, eigener UniStore. Keine CFW-/Formatierungsfunktion. |
| D06 | Reguläre Entwicklung am 3DSX; keine neue native CIA für jedes Update. HOME-Shortcut ermöglicht einfachen Einstieg. | Nutzer „immer über den homebrew launcher ... nicht jedes mal eine neue cia“. Später gewünschte Minimalinstallation liefert Shortcut; das ist kein Widerruf des 3DSX-Updatewegs. Native CIA/Shortcut unterscheiden. |
| D07 | Noch nicht installierte CIA ausgegraut in 3DS-Ansicht, vor Installation Größe/ETA anzeigen. Installer nach erfolgreicher Installation löschen, Seed automatisch prüfen/importieren; Fehler verständlich. | Explizite Nutzeranforderungen; „Installation funktioniert jetzt“, „Seed repair hat super funktioniert“. `cia_install.*`, `game_seed.*`, `main.c`; genaue ältere Version unklar. |
| D08 | Originaltheme-Hintergrund/Musik verwenden, Klicks wie PSP-Auswahl. Musik leiser als Klick. Kein zufällig erfundenes Standard-Musikstück. | Nutzer kritisierte Fallback: „musik ... originale home musik nehmen“; „musik ... deutlich zu laut“. Aktuell Theme-Decoder und .28/.85 Mischung; Originalstandardmusik offen. Die zwischenzeitliche Zustimmung zu eigener Fallback-Komposition wurde anschließend ausdrücklich verworfen. |
| D09 | Originalstandardmusik soll ohne PC funktionieren; nicht durch PC-Import oder öffentliche Nintendo-Audio-Beilage ersetzen. | Nutzerantwort „Standardmusik muss direkt ohne PC funktionieren“. Kein fertiger Standardplayer im aktuellen Code. Private Theme-Fixtures sind kein Distributionsmaterial. |
| D10 | Gewünschte Spiel-Startanimation **entfernen**, nicht reparieren. | Nutzer: „Dieses Feature Nicht fixen nur entfernen“. Noch nicht umgesetzt: Menüoption, Flag/Prefs und Mindestframes existieren. Nicht mit Originalbanner-Animation verwechseln, die bleiben soll. |
| D11 | Autoboot muss HOME, Homebrew und native Spiele korrekt zulassen. Unverändertes Luma und HOME-Prozessstart wurden dem vorgeschlagenen Systemmodul vorgezogen. | Nutzer bat um beste Optionen statt Festlegung auf Luma-Erweiterung. Kleiner HOME-Test: Nutzer hatte zunächst nur START, **nicht HOME** gedrückt; kein Nachweis. Nach Integration: „Ja funktioniert alles“. `prepareNativeHome` bildet den aktuellen Ansatz. Frühere „HOME-Prozess vorhanden“-/Memory-Mode-Fixes allein waren hardwareseitig widerlegt. |
| D12 | DS-Bereitschaft am tatsächlichen Startweg messen, nicht an Downloadpaket-Begaben; eine erneute Prüfung anbieten. | Nutzer DS „missing“ trotz funktionierender Spiele; .31 gemeinsamer Runtime-Check. .31 Hardwarebestätigung steht aus. |
| D13 | TWL Fix nur bei sinnvoller Indikation; keine automatische Löschung aufgrund einzelner ROM-Probleme/fehlender Loader. | Nutzer DS-Check nervte trotz repariertem/ursprünglich funktionierendem DS; neuer Auftrag „prüfe vorher, ob TWL Fix überhaupt sinnvoll ist“. .32 Gate mit externen Tests, Whitelist, Journal, START+A; lokale Prüfung, keine neue Hardwareabnahme. |
| D14 | Desktop auf SD: vorhanden → Reparieren; alte EXE anerkennen; Beigaben reparierbar. | Jüngster Featureauftrag; .33 EXE-/Altnamen-Erkennung, Touch/X-Prüfung. Keine neue Hardwareabnahme. |
| D15 | Suche nutzt beide Screens: unten Tastatur + drei Vorschläge; oben Suchtext und Trefferliste mit Cover/Titel/Kategorie. | Explizite Nutzerbeschreibung, umgesetzt .25; keine konkrete abschließende Abnahme im sichtbaren Verlauf. Keine externe Shopify-/KI-Suche integrieren. |
| D16 | Fehlertexte nennen Ursache und sinnvolle Aktion statt nur Hexcodes. | Nutzer N64 `FFFFFFEC`, fehlender Emulator vermutet; `launch_problem.h`/Preflight. Später trotz installiertem N64 Rücksprung gemeldet; das ist ein anderes ungelöstes Problem, kein Beleg für fehlendes Binary. |
| D17 | POWER-Dialog modern und mit B abbrechbar; mehrfaches Öffnen muss funktionieren. | Nutzer meldete zweiten Druck ohne Wirkung; .27 quittiert zusätzlich den APT-Systemzustand. Noch keine ausdrückliche .27-Abnahme. |
| D18 | Modul-Erkennung und geführte Kopie; PC-Weiterspielen/Save-Sync und Modul-Saves separat später. | Nutzer will einfache Dinge zuerst, komplexe später entscheiden; alte Releaseberichte nennen Saves ausdrücklich nicht migriert. Kein stillschweigender Scope auf Save-Konvertierung. |
| D19 | Neues Projekt zuerst vollständig verstehen und dokumentieren; keine Quellübernahme/Git-Sicherung/Implementierung in dieser Phase. | Aktueller koordinierter Migrationsauftrag; `PROJECT-COPY.md` bestätigt unabhängigen Snapshot. Verbindliche Basisentscheidung steht aus, Empfehlung in MIGRATION. |

Weitere noch offene UI-Wünsche aus der Zehnerliste: About/Support modernisieren und ausklappbare Update-Neuerungen mit kurzen Bulletpoints. Keine Freigabe, sie in diesem Dokumentationsauftrag zu implementieren.

## Lokale Migration 21.10.2026

Der Nutzer beauftragte Start und Fortsetzung des Umstiegs. Nach unabhängiger Prüfung ist Documents/Code/vitarenew-flow die Integrationswurzel; Launcher .33 und Ziel-Desktop .4.1 wurden ausgewählt. Alte Arbeitskopien bleiben erhalten, keine Rücksynchronisation. Eigener lokaler Sicherungsstand und reproduzierbare Prüfung ersetzen die Abhängigkeit vom alten Chat. Das ist keine neue Feature-/Veröffentlichungs- oder Konsolenfreigabe. Details/Nachweise: MIGRATION.md.

## Fehlerberichte und Gerätewechsel — 21.10.2026

Der Nutzer beauftragt einen Meldebutton für Fehlerfälle und wählt einen eigenen Empfangsdienst auf dem Server. Keine automatische Telemetrie: Diagnose-Allowlist statt Rohlogs, optionale bewusste Beschreibung, konkrete Zustimmung vor Versand, feste Größen-/HTTPS-Grenzen. Empfang ist nur nach bestätigter Speicherung erfolgreich. Desktop und externe Abstürze sind gesonderte Integrationsgrenzen. Verwendete Quelle ist Remote-main `815da5a` mit PC-2-Arbeit, nicht der ältere lokale main. Vor allen neuen Aufträgen lokale/Remote-Stände prüfen; ungesendete PC-2-Änderungen lassen sich nicht aus Git ableiten. Öffentliche Serverroute, Benutzerverzeichnis und OTA-Testveröffentlichung .35 hat der Nutzer anschließend ausdrücklich freigegeben.

Abschluss .35: eigener Serverempfang aktiviert, Quell-ZIP reproduziert 3DSX und SMDH bytegleich, unabhängiger Review positiv. Releasecommit 2ada1cd auf main veröffentlicht; Pages39651893937 und13öffentliche Dateien geprüft. Dies ist eine Testveröffentlichung, keine Konsolen-/Stable-Abnahme.
