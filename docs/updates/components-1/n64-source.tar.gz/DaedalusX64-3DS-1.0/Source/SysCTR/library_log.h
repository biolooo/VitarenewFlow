#define LIBRARY_LOG_PATH "sdmc:/3ds/n64-library/last-run.log"
#include "library_diagnostic.h"
