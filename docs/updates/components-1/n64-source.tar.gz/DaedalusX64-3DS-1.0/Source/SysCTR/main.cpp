#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>

#include <3ds.h>
#include <GL/picaGL.h>

#include "BuildOptions.h"
#include "Config/ConfigOptions.h"
#include "Core/Cheats.h"
#include "Core/CPU.h"
#include "Core/CPU.h"
#include "Core/Memory.h"
#include "Core/PIF.h"
#include "Core/RomSettings.h"
#include "Core/Save.h"
#include "Debug/DBGConsole.h"
#include "Debug/DebugLog.h"
#include "Graphics/GraphicsContext.h"
#include "HLEGraphics/TextureCache.h"
#include "Input/InputManager.h"
#include "Interface/RomDB.h"
#include "System/Paths.h"
#include "System/System.h"
#include "Test/BatchTest.h"

#include "UI/UserInterface.h"
#include "UI/RomSelector.h"

#include "Utility/IO.h"
#include "Utility/Preferences.h"
#include "Utility/Profiler.h"
#include "Utility/Thread.h"
#include "Utility/Translate.h"
#include "Utility/Timer.h"
#include "Utility/ROMFile.h"
#include "Utility/MemoryCTR.h"

#include "library_return.h"
#include "library_log.h"
bool isN3DS = false;
bool shouldQuit = false;

EAudioPluginMode enable_audio = APM_ENABLED_ASYNC;

#ifdef DAEDALUS_LOG
void log2file(const char *format, ...) {
	__gnuc_va_list arg;
	int done;
	va_start(arg, format);
	char msg[512];
	done = vsprintf(msg, format, arg);
	va_end(arg);
	sprintf(msg, "%s\n", msg);
	FILE *log = fopen("sdmc:/DaedalusX64.log", "a+");
	if (log != NULL) {
		fwrite(msg, 1, strlen(msg), log);
		fclose(log);
	}
}
#endif

static bool Initialize()
{
	libraryTrace("kernel-services");
	if(!_InitializeSvcHack())libraryTrace("legacy svc hack unavailable; checking actual JIT permissions on ROM load");

	libraryTrace("romfs");
	if(R_FAILED(romfsInit())){libraryTrace("ERROR romfs");return false;}
	
	APT_CheckNew3DS(&isN3DS);
	osSetSpeedupEnable(true);
	
	gfxInit(GSP_BGR8_OES, GSP_BGR8_OES, true);

	if(isN3DS)
		gfxSetWide(true);
	
	libraryTrace("picaGL revamp init");
	pglInitEx(0x080000,0x040000);
	libraryTrace("picaGL ready");

	strcpy(gDaedalusExePath, DAEDALUS_CTR_PATH(""));
	strcpy(g_DaedalusConfig.mSaveDir, DAEDALUS_CTR_PATH("SaveGames/"));

	IO::Directory::EnsureExists( DAEDALUS_CTR_PATH("SaveStates/") );
	libraryTrace("UI font init");
	UI::Initialize();
	libraryTrace("UI ready");

	libraryTrace("system init");
	bool ready=System_Init();
	libraryTrace(ready?"system ready":"ERROR system init");
	return ready;
}


void HandleEndOfFrame()
{
	hidScanInput();
    shouldQuit = !aptMainLoop() || libraryReturnRequested();
	
	if (shouldQuit)
	{
		CPU_Halt("Exiting");
	}
}

static void LibraryVblank(void*) {
    static bool logged=false;if(!logged){libraryTrace("first emulated VBlank");logged=true;}
    HandleEndOfFrame();
}
static void LibraryError(const char *message) {
    consoleInit(GFX_BOTTOM,NULL);consoleClear();
    printf("N64 Library 0.6.1\n\n%s\n\nSTART oder L+R+Y: Library\n",message);
    while(aptMainLoop()) {hidScanInput();if((hidKeysDown()&KEY_START)||libraryReturnRequested())break;gfxFlushBuffers();gfxSwapBuffers();gspWaitForVBlank();}
    librarySetReturnTarget();
}
extern u32 __ctru_heap_size;

int main(int argc, char* argv[])
{
	char fullpath[512];

	libraryBeginTrace();
	if(!Initialize()){LibraryError("Initialisierung fehlgeschlagen. last-run.log pruefen.");return 1;}
	CPU_RegisterVblCallback(LibraryVblank,NULL);
	
	while(shouldQuit == false)
	{
		if(argc==2 && argv[1]) { snprintf(fullpath,sizeof(fullpath),"%s",argv[1]); argc=0; }
        else { std::string rom=UI::DrawRomSelector(); snprintf(fullpath,sizeof(fullpath),"%s%s",DAEDALUS_CTR_PATH("Roms/"),rom.c_str()); }

        libraryTrace(fullpath);libraryTrace("ROM open");
        if(!System_Open(fullpath)){libraryTrace("ERROR ROM open");LibraryError("ROM konnte nicht geladen werden.");break;}
        libraryTrace("ROM ready; CPU run");
        CPU_Run();
        libraryTrace("CPU stopped; save and close");
        System_Close();
	}
	
	CPU_UnregisterVblCallback(LibraryVblank,NULL);
	libraryTrace("normal cleanup");
	librarySetReturnTarget();
	System_Finalize();
	pglExit();

	return 0;
}
