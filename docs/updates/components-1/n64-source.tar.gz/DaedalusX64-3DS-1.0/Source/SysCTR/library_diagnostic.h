#ifndef LIBRARY_DIAGNOSTIC_H
#define LIBRARY_DIAGNOSTIC_H
#include <stdio.h>
static inline void libraryTrace(const char *stage) {
    FILE *f=fopen(LIBRARY_LOG_PATH,"a");if(f){fprintf(f,"%s\n",stage);fclose(f);}
}
static inline void libraryBeginTrace(void) {
    FILE *f=fopen(LIBRARY_LOG_PATH,"w");if(f){fputs("Library adapter 0.6.1\n",f);fclose(f);}
}
#endif
