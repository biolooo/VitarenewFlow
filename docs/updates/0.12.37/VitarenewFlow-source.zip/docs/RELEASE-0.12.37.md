# VitarenewFlow 0.12.37

- Übersichtlichere About-Seite mit klar getrennten Textzeilen.
- Dezenter Meldebutton mit eigener X-Tastenmarkierung.

Nutzerfreigabe 21.10.2026: „Dann veröffentliche mal als Update.“ Basis9773f60; vorher Remote-main2f4356c. Enthält außerdem den lokal gesicherten lesenden Reportgruppierer aus46e69ee; keine neue Apptelemetrie, keine Dienständerung. Desktop .4.1 und veröffentlichte .36-Pakete bleiben unverändert. Skillvorlage im Repository für Wiederverwendung auf PC2.

Frischer nativer Build, Hostprüfungen und exakte Source-ZIP-Reproduktion sind Releasevoraussetzung. Öffentlicher Workflow-/Bytenachweis wird nach Bereitstellung ergänzt. Keine .37-Konsolenabnahme.
