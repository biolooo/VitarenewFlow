from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import json,shutil
base=Path(__file__).resolve().parents[1];work=base/'tools/fonts';app=base
atlas=Image.new('RGBA',(512,512));draw=ImageDraw.Draw(atlas);x=y=row=0;glyphs=[];faces=[]
codes=list(range(32,127))+list(range(160,256))+[0x2013,0x2014,0x2022,0x2026,0x2190,0x2191,0x2192,0x2193,0x25b6]
for size,weight in [(12,500),(14,550),(18,600),(26,600)]:
 font=ImageFont.truetype(str(work/'InterVariable.ttf'),size);font.set_variation_by_axes([14,weight]);ascent,descent=font.getmetrics();start=len(glyphs)
 for code in codes:
  ch=chr(code);left,top,right,bottom=font.getbbox(ch,anchor='ls');w=right-left;h=bottom-top
  if x+w+2>512:x=0;y+=row;row=0
  if y+h+2>512:raise ValueError('Atlas overflow')
  draw.text((x-left+1,y-top+1),ch,font=font,fill='white',anchor='ls')
  glyphs.append([code,x+1,y+1,w,h,left,ascent+top,round(font.getlength(ch))]);x+=w+3;row=max(row,h+3)
 faces.append([size,start,len(codes),ascent+descent])
dst=app/'SD-Karte/3ds/3ds-library/assets';dst.mkdir(parents=True,exist_ok=True);atlas.save(dst/'inter-atlas.png')
shutil.copy2(work/'Inter-LICENSE.txt',dst/'Inter-OFL.txt')
header='/* Generated from Inter Variable, SIL Open Font License 1.1. */\n#pragma once\n#include <stdint.h>\ntypedef struct {uint32_t code;uint16_t x,y,w,h;int16_t dx,dy,advance;} UiGlyph;\ntypedef struct {unsigned size,start,count,lineHeight;} UiFace;\nstatic const UiFace ui_faces[]={\n'
header+=''.join('{'+','.join(map(str,f))+'},\n' for f in faces)+'};\nstatic const UiGlyph ui_glyphs[]={\n'
header+=''.join('{'+','.join(map(str,g))+'},\n' for g in glyphs)+'};\n'
(app/'source/ui_font_data.h').write_text(header,encoding='utf-8')
(work/'font-metrics.json').write_text(json.dumps(dict(faces=faces,glyphs=glyphs)))
print('Inter atlas:',len(glyphs),'glyphs, height',y+row,'/512; fixed native 12/14/18/26px')
