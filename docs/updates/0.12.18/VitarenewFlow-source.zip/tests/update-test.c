#include "update_format.h"
#include "update_store.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static char data[1024];
static void make(const char *version,const char *size,const char *url){snprintf(data,sizeof(data),"VFUPDATE1\nversion=%s\nsize=%s\nsha256=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\nurl=%s\n",version,size,url);}
static bool app,stage,backup;static unsigned moves,failMove,failMove2;static bool eraseFail;
static bool exists(const char *p){return !strcmp(p,UPDATE_APP)?app:!strcmp(p,UPDATE_STAGE)?stage:backup;}
static bool *entry(const char *p){return !strcmp(p,UPDATE_APP)?&app:!strcmp(p,UPDATE_STAGE)?&stage:&backup;}
static int move(const char *a,const char *b){moves++;if(moves==failMove||moves==failMove2||!(*entry(a))||*entry(b))return -1;*entry(a)=false;*entry(b)=true;return 0;}
static int erase(const char *p){if(eraseFail)return -1;*entry(p)=false;return 0;}
static void reset(void){app=stage=true;backup=false;moves=failMove=failMove2=0;eraseFail=false;}
int main(void){
 UpdateManifest m;const char *url=UPDATE_URL_ROOT "0.12.18/VitarenewFlow.3dsx";
 make("0.12.18","900000",url);assert(update_manifest_parse(data,strlen(data),&m));assert(m.bytes==900000);
 assert(update_version_compare("0.12.18","0.12.17")==1);assert(update_version_compare("0.12.18","0.12.18")==0);assert(update_version_compare("0.12.16","0.12.18")==-1);assert(update_version_compare("0.12.9","0.12.10")==-1);assert(update_version_compare("0.12.18x","0.12.17")==-2);
 char saved[1024];strcpy(saved,data);
 for(size_t n=0;n<strlen(saved);n++)assert(!update_manifest_parse(saved,n,&m));
 const char *sizes[]={"0","31","8388609","9999999999999999999999999","-1","64x"};
 for(unsigned i=0;i<sizeof(sizes)/sizeof(*sizes);i++){make("0.12.18",sizes[i],url);assert(!update_manifest_parse(data,strlen(data),&m));}
 const char *urls[]={"http://biolooo.github.io/VitarenewFlow/updates/0.12.18/VitarenewFlow.3dsx",UPDATE_URL_ROOT "../VitarenewFlow.3dsx","https://evil.example/VitarenewFlow.3dsx",UPDATE_URL_ROOT "0.12.18/VitarenewFlow.3dsx?x=1"};
 for(unsigned i=0;i<sizeof(urls)/sizeof(*urls);i++){make("0.12.18","900000",urls[i]);assert(!update_manifest_parse(data,strlen(data),&m));}
 make("0.12.18","900000",url);data[15]=0;assert(!update_manifest_parse(data,200,&m));
 for(unsigned i=0;i<20000;i++){size_t n=(unsigned)rand()%1024;for(size_t j=0;j<n;j++)data[j]=(char)rand();update_manifest_parse(data,n,&m);}
 UpdateFs fs={exists,move,erase};
 reset();assert(update_store_commit(&fs)==0&&app&&backup&&!stage);
 reset();backup=true;assert(update_store_commit(&fs)==0&&app&&backup&&!stage);
 reset();backup=true;eraseFail=true;assert(update_store_commit(&fs)==-1&&app&&backup&&stage);
 reset();failMove=1;assert(update_store_commit(&fs)==-1&&app&&!backup&&stage);
 reset();failMove=2;assert(update_store_commit(&fs)==-1&&app&&!backup&&stage);
 reset();failMove=2;failMove2=3;assert(update_store_commit(&fs)==-2&&!app&&backup&&stage);
 reset();stage=false;assert(update_store_commit(&fs)==-1&&app);
 puts("PASS: strict manifests, semver/downgrade ordering, truncated/oversized/foreign-URL rejection, 20000 malformed inputs, FAT swap and failure/rollback paths");
}