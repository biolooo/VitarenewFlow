#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
typedef int Result;typedef unsigned NS_APPID;typedef uint32_t u32;
#define R_FAILED(r) ((r)<0)
enum {FLAG_ACTIVE=1,FLAG_ALLOWSLEEP=4,FLAG_SHOULDHOME=32,FLAG_POWERBUTTON=128,FLAG_ORDERTOCLOSE=512,FLAG_CANCELLED=1024};
enum {KEY_A=1,KEY_B=2,KEY_X=4,KEY_Y=8,KEY_SELECT=16,KEY_TOUCH=32};
static unsigned aptFlags;static int aptHomeButtonState;
static bool powerPrompt,homeUnavailable,installing,preparingGame,uiReleased,leave,exitToHomebrew,allowPending;
static unsigned twlPage,selected,flow;static const char *status;
static struct {int px,py;}pos;
static int unlocks,sleeps,homeCalls,reboots,shutdowns,musicResumes,resets,homeJumps;
static bool registered;
static void APT_UnlockTransition(unsigned n){assert(n==1);unlocks++;}
static void APT_SleepIfShellClosed(void){sleeps++;}
static const char *tr(const char *s){return s;}
static void aptHandleSleep(void){}
static bool aptCheckHomePressRejected(void){return false;}
static NS_APPID aptGetMenuAppID(void){return 0x101;}
static Result APT_IsRegistered(NS_APPID menu,bool *value){assert(menu==0x101);*value=registered;return 0;}
static void app_log(const char*s){(void)s;}
static void ui_runtime_allow_pending_home(bool b){allowPending=b;}
static void ui_runtime_drain(void){}
static void ui_runtime_reset(void){resets++;}
static void aptHandleJumpToHome(void){homeJumps++;aptFlags&=~(FLAG_SHOULDHOME|FLAG_POWERBUTTON);aptHomeButtonState=0;}
static void openHomeMenu(void){homeCalls++;}
static void systemPowerAction(bool reboot){if(reboot)reboots++;else shutdowns++;}
static void flow_reset(unsigned *f,unsigned n){*f=n;}
static void menu_music_pause(bool p){assert(!p);musicResumes++;}
bool aptShouldClose(void)
{
	return (aptFlags & (FLAG_ORDERTOCLOSE|FLAG_CANCELLED)) != 0;
}
bool aptShouldJumpToHome(void)
{
	return aptHomeButtonState || (aptFlags & (FLAG_SHOULDHOME|FLAG_POWERBUTTON)) != 0;
}
static void aptClearJumpToHome(void)
{
	aptHomeButtonState = 0;
	APT_UnlockTransition(0x01);
	APT_SleepIfShellClosed();
}
void flow_apt_cancel_home_request(void)
{
    if (aptShouldClose()) return;
    __atomic_fetch_and(&aptFlags, ~(FLAG_SHOULDHOME | FLAG_POWERBUTTON), __ATOMIC_ACQ_REL);
    aptClearJumpToHome();
}
static bool flowMainLoop(void){
    aptHandleSleep();
    /* HOME is intercepted only in a coldboot session; POWER retains its dialog.
       Do not leave while an install/preflight/repair owns the foreground. */
    if(homeUnavailable&&aptCheckHomePressRejected()&&!installing&&!preparingGame&&twlPage!=3){
        openHomeMenu();
    }
    if(aptShouldJumpToHome()){
        bool registered=false;NS_APPID menu=aptGetMenuAppID();Result r=APT_IsRegistered(menu,&registered);
        char entry[100];snprintf(entry,sizeof(entry),"HOME request: menu=%u registered=%u result=%08lX",(unsigned)menu,registered,(unsigned long)(u32)r);if(!powerPrompt)app_log(entry);
        if(R_FAILED(r)||!registered){
            /* libctru screen-transfer waits indefinitely for an absent HOME.
               Stay active and offer PTM power controls instead. */
            ui_runtime_allow_pending_home(true);
            if(!powerPrompt)status=tr("Autostart pausiert bis zum nächsten Öffnen der Library.");
            powerPrompt=true;return !aptShouldClose();
        }
        ui_runtime_allow_pending_home(false);
        if(!uiReleased)ui_runtime_drain();
        aptHandleJumpToHome();
    }
    return !aptShouldClose();
}
static void input(unsigned keys){        if(powerPrompt){
            if(keys&KEY_TOUCH){
                if(pos.px>=12&&pos.px<308){
                    if(pos.py>=54&&pos.py<85)keys|=KEY_A;
                    else if(pos.py>=91&&pos.py<122)keys|=KEY_X;
                    else if(pos.py>=128&&pos.py<159)keys|=KEY_Y;
                    else if(pos.py>=165&&pos.py<196)keys|=KEY_SELECT;
                    else if(pos.py>=205&&pos.py<235)keys|=KEY_B;
                }
            }
            if(keys&KEY_B){
                flow_apt_cancel_home_request();
                powerPrompt=false;ui_runtime_allow_pending_home(false);ui_runtime_reset();
                flow_reset(&flow,selected);status=tr("Bereit");
                menu_music_pause(false);app_log("Power dialog cancelled; pending HOME/POWER cleared");
            }else if(keys&KEY_A){openHomeMenu();if(uiReleased)leave=true;}
            else if(keys&(KEY_X|KEY_SELECT)){
                systemPowerAction((keys&KEY_X)!=0);
                status=tr("Systemanfrage fehlgeschlagen; erneut versuchen");if(uiReleased)leave=true;
            }else if(keys&KEY_Y){powerPrompt=false;exitToHomebrew=true;leave=true;}
}}

int main(void){
 aptFlags=FLAG_ACTIVE|FLAG_ALLOWSLEEP|FLAG_POWERBUTTON;assert(flowMainLoop()&&powerPrompt&&allowPending);
 unsigned preserved=aptFlags&~FLAG_POWERBUTTON;
 input(KEY_B);assert(!powerPrompt&&!allowPending&&!aptShouldJumpToHome()&&aptFlags==preserved);
 assert(unlocks==1&&sleeps==1&&musicResumes==1&&resets==1&&!leave&&!exitToHomebrew);
 for(int i=0;i<100;i++){assert(flowMainLoop());assert(!powerPrompt);}
 aptFlags|=FLAG_POWERBUTTON;assert(flowMainLoop()&&powerPrompt);input(KEY_B|KEY_A|KEY_X|KEY_SELECT);assert(!powerPrompt&&!homeCalls&&!shutdowns&&!reboots);
 aptFlags|=FLAG_SHOULDHOME;aptHomeButtonState=1;assert(flowMainLoop()&&powerPrompt);pos.px=150;pos.py=218;input(KEY_TOUCH);assert(!powerPrompt&&!aptShouldJumpToHome());
 powerPrompt=true;pos.px=150;pos.py=88;input(KEY_TOUCH);assert(powerPrompt&&!homeCalls);input(KEY_B);
 powerPrompt=true;pos.py=65;input(KEY_TOUCH);assert(homeCalls==1);input(KEY_B);
 powerPrompt=true;pos.py=100;input(KEY_TOUCH);assert(reboots==1);input(KEY_B);
 powerPrompt=true;pos.py=175;input(KEY_TOUCH);assert(shutdowns==1);input(KEY_B);
 powerPrompt=true;pos.py=140;input(KEY_TOUCH);assert(exitToHomebrew&&leave&&!powerPrompt);
 aptFlags=FLAG_ACTIVE|FLAG_POWERBUTTON|FLAG_ORDERTOCLOSE;flow_apt_cancel_home_request();assert(aptFlags&FLAG_ORDERTOCLOSE);assert(aptFlags&FLAG_POWERBUTTON);
 aptFlags=FLAG_ACTIVE|FLAG_POWERBUTTON;registered=true;assert(flowMainLoop());assert(homeJumps==1&&!allowPending);
 puts("PASS: actual APT cancellation + main loop + dispatcher: B/touch, sticky flags, repeated reopen, cancel priority, all actions, real close preserved, registered HOME path");
}
