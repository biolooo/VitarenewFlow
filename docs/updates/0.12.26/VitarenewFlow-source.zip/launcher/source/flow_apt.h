// SPDX-License-Identifier: GPL-3.0-only
#pragma once
void flow_apt_cancel_home_request(void);
