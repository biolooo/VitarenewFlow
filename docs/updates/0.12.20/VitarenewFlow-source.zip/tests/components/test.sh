set -eu
ROOT=/home/maxim/codex-3ds-work/toolchain
TASK=/mnt/c/Users/subje/Documents/Codex/2026-10-13/kan
mkdir -p "$ROOT/component-test"
cp "$TASK/work/components-v01220/transaction-test.c" "$ROOT/component-test/"
cp "$TASK/outputs/3ds-library/source/components.h" "$TASK/outputs/3ds-library/source/component_catalog.h" "$ROOT/component-test/"
chroot "$ROOT" /bin/bash -c 'cd /component-test; gcc -std=c11 -Wall -Wextra -Werror -fsanitize=undefined transaction-test.c -o transaction-test; ./transaction-test'
cp "$TASK/work/components-v01220/input-test.c" "$ROOT/component-test/"
chroot "$ROOT" /bin/bash -c 'cd /component-test; gcc -std=c11 -Wall -Wextra -Werror -fsanitize=undefined input-test.c -o input-test; ./input-test'
